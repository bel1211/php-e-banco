<?php

 include_once './connetion.php';

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <main>
        <h2>Enviar mensagem</h2>
        <?php

        $data = filter_input_array(INPUT_POST, FILTER_DEFAULT);

        if (!empty($data['add_msg'])) {
            // var_dump($data);

            try {
                $consulta = $conn->prepare("INSERT INTO contato_msg (name, email, subject, pet) VALUES (:name, :email, :subject, :pet)");

            $consulta->bindParam(":email", $data["email"]);
            $consulta->bindParam(":subject", $data["subject"]);
            $consulta->bindParam(":name", $data["name"]);
            $consulta->bindParam(":pet", $data["pet"]);
            $consulta->execute();

            echo $consulta->rowCount();
            } catch (PDOException  $e) {
                    echo 'Error: ' . $e->getMessage();

            }
        }
        ?>
        <form name="add_msg" action="" method="POST" id="staticform">

            <label>Nome:</label>
            <input type="text" name="name" id="name" placeholder="Digite o nome completo" required><br><br>

            <label>Email:</label>
            <input type="text" name="email" id="name" placeholder="Digite o seu email" required><br><br>

            <label>N° de celular:</label>
            <input type="tel" name="subject" id="subject" placeholder="Digite o n° do seu celular" required><br><br>

            <label>Qualé a raça do pet:</label>
            <input type="text" name="pet" id="pet" placeholder="Digite qual é seu pet" required><br><br>

            <input type="hidden" name="accessKey" value="07461c51-22bb-4f0d-ae91-7e627413ae65">
            <input type="hidden" name="redirectTo" value="http://localhost/idex.php">

            <input type="submit" value="Enviar" name="add_msg">
        </form>
    </main>


    <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
    <script>
        $("#staticform").submit(function(event) {

        // });
        // $("#staticform").submit(function(event) {
            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: 'https://api.staticforms.xyz/submit',
                async: false,
                data: $("#staticform").serialize(),
                success: function(response) {
                    location.reload();
                }
            });

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: './idex.php',
                async: false,
                data: $("#staticform").serialize(),
                success: function(response) {
                    location.reload();
                }
            });
        });
    </script>
</body>

</html>