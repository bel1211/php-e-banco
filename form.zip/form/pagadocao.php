
<?php

include_once './conex_banco.php';

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css" type="text/css">
    <title>Pet´s Mania</title>
</head>
<body>

    <main>

        <header>

            <div class="esquerda">
                <div class="logo">
                    <a href="index.html">
                        <img src="imagens/logo.png" alt="Logotipo do Pets Mania" title="Vá para o Início">
                    </a>
                </div>

                <div class="pesquisa">
                    <div class="caixa_pesquisa">
                        <input type="text" class="searchTerm" placeholder="O que seu pet precisa?">
                        <button type="submit" class="searchButton">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="direita">
                <button class="custom-btn-btn-1">Entrar | Cadastrar</button>
                <button class="custom-btn-btn-3"> <i class="fa-regular fa-heart"></i></button>
                <button class="custom-btn-btn-2"><i class="fa-solid fa-cart-shopping"></i></button>
            </div>

            <div id="menu-superior">
                <ul id="lista-menu">
                    <li><a href="index.html">Início</a></li>
                    <li class="pagquemsomos"> <a href="pagquemsomos.html" class="pagquemsomos">Quem Somos</a></li>
                    <li><a href="castracao.html">castração</a></li>
                    <li class="pagadocao"> <a href="pagadocao.html" class="pagadocao">Adoção de Pet's</a></li>
                    <li>Fale Conosco</li>
                </ul>


            </div>

        </header>
        <!--Fim da Header--> 
    <h1 id="secao-titulo-esquerdo"> Adoções </h1>

    <h1 id="secao-titulo-superior"> Dog's </h1>

    <div class="anuncio">
      <div class="branco">
        <img src="imagens/adotar1.jpg" alt="anuncio adoação" title="anuncio de doação gato">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>




      <div class="branco">
        <img src="imagens/adotar2.jpg" alt="anuncio adoação" title="anuncio de doação cachorro">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>




      <div class="branco">
        <img src="imagens/adotar3.jpg" alt="anuncio adoação" title="anuncio  de doação cachorro">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>




      <div class="branco">
        <img src="imagens/adotar4.jpg" alt="anuncio adoação" title="anuncio de doação gato">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>

    </div>

    <!--imagens e tirulos e inferiores inicio-->

    <h1 id="secao-titulo-inferior">Cat's </h1>

    <div class="anuncio">
      <div class="azul">
        <img src="imagens/adotar gato 1.png" alt="anuncio adoação" title="anuncio de doação gato">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>




      <div class="azul">
        <img src="imagens/adotar gato 2.jpeg" alt="anuncio adoação" title="anuncio de doação cachorro">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>




      <div class="azul">
        <img src="imagens/adotar gato 3.jpeg" alt="anuncio adoação" title="anuncio  de doação cachorro">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>




      <div class="azul">
        <img src="imagens/adotar gato 4.jpg" alt="anuncio adoação" title="anuncio de doação gato">
        <p> <a href="#" target="_blank" class="pagquemsomos">ADOTAR</a></p>
      </div>

    </div>


    <!--imagens e tirulos e inferiores fim-->




    <!--formulario e titulo de banho inicio-->



    <h1 class="formulario-titulo-inferior">Banhos (Tosa ou ozônio)</h1>


    <p id="formulario-borda-inferior"> Agende seu horário </p>

    <?php
        $data = filter_input_array(INPUT_POST, FILTER_DEFAULT);
        
        if(!empty($data['cadastro_teste'])){
            var_dump($data);

            try {
                $consulta = $conn->prepare("INSERT INTO agendamento (nomet, email, telefone, nomebutton, dia, horario, nomer) VALUES (:nomet, :email, :telefone, :nomebutton, :dia, :horario, :nomer)");

                $consulta->bindParam(":email", $data["email"]);
                $consulta->bindParam(":nomet", $data["nomet"]);
                $consulta->bindParam(":telefone", $data["telefone"]);
                $consulta->bindParam(":nomebutton", $data["nomebutton"]);
                $consulta->bindParam(":dia", $data["dia"]);
                $consulta->bindParam(":horario", $data["horario"]);
                $consulta->bindParam(":nomer", $data["nomer"]);
                $consulta->execute();

                echo $consulta->rowCount();
            } catch (PDOException  $e) {
                echo 'Error: ' . $e->getMessage();
            }
        }
    ?>

    <section id="formulario">

      <br>

      <form id="id-formulario" action="" name="cadastro_teste" method="POST">

        <div id="formulario-esquerdo">
          <fieldset>

            <label for="nome-tutor">Nome do Tutor:</label>


            <input type="text" name="nomet" id="nomet" size="50" maxlength="50" required
              placeholder="Entre com o nome do tutor">

            <br>
            <br>

            <label for="telefone">N° celular:</label>
            <input type="tel" name="telefone" id="telefone" size="50" maxlength="50"
             placeholder="Entre com o numero do celular" required>

            <br>
            <br>

            <label for="nome-raca">Raça do seu pet:</label>

            <input type="text" name="nomebutton" id="nomebutton" size="50" maxlength="50" required
              placeholder="Entre com a raça do seu pet">

            <h1 id="formulario-h1">Entraremos em contato pelo Whatsapp para a confirmação</h1>


        </div>


        <div id="formulario-direito">

          <fieldset>

            <label for="nome-data">Data:</label>


            <input type="date" name="dia" id="dia" size="50" maxlength="50" required
              placeholder="Entre com a data de agendaento">

            <br>
            <br>

            <label for="harario">horario:</label>
            <input type="time" name="horario" id="horario" size="50" maxlength="50"
              placeholder="Entre com o harario de agendamento" required>

            <br>
            <br>

            <label for="nome-raca">Porte do pet:</label>


            <input type="text" name="nomer" id="nomer" size="50" maxlength="50" required
              placeholder="Entre com o porte do seu pet">

            <hr>
            <hr>

            <div id="button-div">
              <input id="button-i" type="submit" value="Agendar" name="cadastro_teste">
            </div>


        </div>
    </form>


    </section>


    <!--formulario e titulo de banho fim-->


        <!--Começo do Footer-->
        <footer>
            <div class="box">
                <div class="social">
                    <i class="fa-brands fa-facebook"></i>
                    <!--icones do link fontawesome-->
                    <i class="fa-brands fa-instagram"></i>
                    <i class="fa-brands fa-twitter"></i>
                    <i class="fa-brands fa-youtube"></i>
                </div>


                <div class="info">
                    <ul>
                        <li>inicio</li>
                        <li>Ajuda online</li>
                        <li>Politica de promoções</li>
                        <li>Politica de privacidade</li>
                    </ul>
                </div>

                <div class="info">
                    <ul>
                        <li>Pet´inicio</li>
                        <li>Campanhas sociais</li>
                        <li>Eventos</li>
                        <li>Trabalhe conosco</li>
                    </ul>
                </div>

                <div class="info">
                    <ul>
                        <li>Esinicio</li>
                        <li>Black friday</li>
                        <li>Pet idoso</li>
                        <li>Cupom de desconto</li>
                    </ul>
                </div>

                <p><i class="fa-regular fa-copyright"></i> Instituto Proa</p>
            </div>

        </footer>


    </main>

</body>

</html>