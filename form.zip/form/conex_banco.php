<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "celke";
$port= 3306;


try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
} catch (\Throwable $th) {
    throw $th;
}

?>